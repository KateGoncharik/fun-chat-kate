export type UserData = {
  login: string;
  password: string;
};
