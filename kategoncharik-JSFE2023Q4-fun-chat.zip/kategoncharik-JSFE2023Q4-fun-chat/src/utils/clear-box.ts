export default function clearBox(element: HTMLElement): void {
  const elementToClear = element;
  elementToClear.innerHTML = "";
}
